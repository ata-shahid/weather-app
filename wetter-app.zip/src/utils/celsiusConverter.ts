
export function celsiusConverter(kelvin: number): number {
  return Math.round(kelvin - 273.15);
}
